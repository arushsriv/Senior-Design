
import React, { useState, useEffect } from 'react';
import Navigation from './components/Menu';
import Footer from './components/Footer';
import CreditCardComponent from './components/CreditCardComponent'
import "./css/cardOffers.css"


const CardOffersPage = () => {

  const [filteredCards, setFilteredCards] = useState([]);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [userPreferences, setUserPreferences] = useState(null);
  const username = sessionStorage.getItem('username');
  const  [debtToIncomeRatio, setdebtRatio] = useState();
  const  [newCards, setNewCards] = useState();
  const  [annualFeePreference, setAnnualFeePreference] = useState();
  const  [annualFeeLimit, setAnnualFeeLimit] = useState();
  const  [bonusWeight, setBonusWeight] = useState();
  const  [monthlyBalance, setMonthlyBalance] = useState();
  const  [ficoScore, setFicoScore] = useState();
  const  [highSpending, setHighSpending] = useState();
  const  [preferredStore, setPreferredStore] = useState('amazon');


useEffect(() => {
  (async () => {
    try {
      const response = await fetch(`/getpreferences/${username}`); 
      console.log('userPreferences after fetch: ', response);
      if (!response.ok) {
        throw new Error('Failed to fetch preferences');
      }
      const data = await response.json();
      console.log(response.data);
      setUserPreferences(data.data);
      setdebtRatio(parseInt(data.data.debt_income_ratio));
      setNewCards(parseInt(data.data.number_cc));
      setAnnualFeeLimit(parseInt(data.data.price));
      setMonthlyBalance(parseInt(data.data.monthlyBalance));
      setFicoScore(parseInt(data.data.fico));
      setHighSpending(data.data.categories);
      if (data.data.fee_pref === 'yes') {
        setAnnualFeePreference(true);
      } else {
        setAnnualFeePreference(false);
      }
      if (data.data.bonus === 'Only bonus deals'){
        setBonusWeight(0);
      } else {
        setBonusWeight(1);
      }
      handleFilterSubmit();
    } catch (error) {
      console.error(error.message);
    }
  })();
}, []);




  const handleFilterSubmit = async () => {
    try {
      const response = await fetch('http://localhost:8080/getTopCreditCards', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          debtToIncomeRatio,
          newCards,
          annualFeePreference,
          annualFeeLimit,
          bonusWeight,
          monthlyBalance,
          ficoScore,
          highSpending,
          preferredStore
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch recommendations');
      }

      const data = await response.json();
      setFilteredCards(data.topCards);
      console.log(data.topCards)
    } catch (error) {
      console.error(error.message);
    }
  };

  return (
    <div className="layout">
      <header className="headerAppName">
        <h1>Budgify</h1>
      </header>

      <div className="main-content">
        <div>
          <Navigation />
        </div>

        <div className="line-delimiter" />

        <section className="content">
          <div className="card-offers">
            <h1>Card Offers</h1>

            {/* Render CardFilterForm with onSubmit handler */}

            <div>
              {/* Render filtered cards */}


              {filteredCards && filteredCards.length > 0 &&
                <CreditCardComponent creditCards={filteredCards} />
              }
            </div>
          </div>
        </section>
      </div>
      <div>
        <Footer />
      </div>
    </div>
  );
};
export default CardOffersPage;